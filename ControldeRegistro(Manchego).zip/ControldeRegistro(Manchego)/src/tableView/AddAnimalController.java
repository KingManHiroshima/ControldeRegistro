/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tableView;

import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXTextField;
import helpers.DbConnect;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.input.MouseEvent;
import models.Animal;

/**
 * FXML Controller class
 *
 * @author Tk
 */
public class AddAnimalController implements Initializable {

    @FXML
    private JFXTextField nroFld;
    @FXML
    private JFXDatePicker fechaFld;
    @FXML
    private JFXTextField sexoFld;
    @FXML
    private JFXTextField razaFld;
    @FXML
    private JFXTextField colorFld;
    @FXML
    private JFXTextField madreFld;
    @FXML
    private JFXTextField padreFld;
    @FXML
    private JFXTextField pesonFld;
    @FXML
    private JFXTextField pesodFld;
    @FXML
    private JFXTextField prodFld;

    String query = null;
    Connection connection = null;
    ResultSet resultSet = null;
    PreparedStatement preparedStatement;
    Animal animal = null;
    private boolean update;
    int animalId;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void save(MouseEvent event) {
        
        connection = DbConnect.getConnect();
        String nro = nroFld.getText();
        String fecha = String.valueOf(fechaFld.getValue());
        String sexo = sexoFld.getText();
        String raza = razaFld.getText();
        String color = colorFld.getText();
        String madre = madreFld.getText();
        String padre = padreFld.getText();
        String peson = pesonFld.getText();
        String pesod = pesodFld.getText();
        String prod = prodFld.getText();

        if (nro.isEmpty() || fecha.isEmpty() || sexo.isEmpty() || raza.isEmpty() || color.isEmpty() || madre.isEmpty() || padre.isEmpty() || peson.isEmpty() || pesod.isEmpty() || prod.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setContentText("Por favor llene toda la data");
            alert.showAndWait();

        } else {
            getQuery();
            insert();
            clean();
        }
    }

    @FXML
    private void clean() {
        nroFld.setText(null);
        fechaFld.setValue(null);
        sexoFld.setText(null);
        razaFld.setText(null);
        colorFld.setText(null);
        madreFld.setText(null);
        padreFld.setText(null);
        pesonFld.setText(null);
        pesodFld.setText(null);
        prodFld.setText(null);

    }

    private void getQuery() {

        if (update == false) {

            query = "INSERT INTO `animal`(`nro.delanimal`, `fechadenacimiento`, `sexo`, `raza`, `color`, `madre`, `padre`, `pesoalnacer`, `pesoaldestete`, `producidopor`) VALUES (?,?,?,?,?,?,?,?,?,?)";

        } else {
            query = "UPDATE `animal` SET "
                    + "`nro.delanimal`=?,"
                    + "`fechadenacimiento`=?,"
                    + "`sexo`=?,"
                    + "`raza`=?,"
                    + "`color`=?,"
                    + "`madre`=?,"
                    + "`padre`=?,"
                    + "`pesoalnacer`=?,"
                    + "`pesoaldestete`=?,"
                    + "`producidopor`= ? WHERE id = '" + animalId + "'";
        }
    }

    private void insert() {

        try {

            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, nroFld.getText());
            preparedStatement.setString(2, String.valueOf(fechaFld.getValue()));
            preparedStatement.setString(3, sexoFld.getText());
            preparedStatement.setString(4, razaFld.getText());
            preparedStatement.setString(5, colorFld.getText());
            preparedStatement.setString(6, madreFld.getText());
            preparedStatement.setString(7, padreFld.getText());
            preparedStatement.setString(8, pesonFld.getText());
            preparedStatement.setString(9, pesodFld.getText());
            preparedStatement.setString(10, prodFld.getText());
            preparedStatement.execute();

        } catch (SQLException ex) {
            Logger.getLogger(AddAnimalController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    void setTextField(int id, String nro, LocalDate toLocalDate, String sexo, String raza, String color, String madre, String padre,
             String pesoalnacer, String pesoaldestete,
             String prodpor) {

        animalId = id;
        nroFld.setText(nro);
        fechaFld.setValue(toLocalDate);
        sexoFld.setText(sexo);
        razaFld.setText(raza);
        colorFld.setText(color);
        madreFld.setText(madre);
        padreFld.setText(padre);
        pesonFld.setText(pesoalnacer);
        pesodFld.setText(pesoaldestete);
        prodFld.setText(prodpor);
    }

    void setUpdate(boolean b) {
        this.update = b;

    }

}
