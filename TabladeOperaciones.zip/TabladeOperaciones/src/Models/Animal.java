/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

import java.sql.Date;

/**
 *
 * @author Tk
 */
public class Animal {

    int nro;
    Date fechaden;
    String sexo;
    String raza;
    String color;
    String madre;
    String padre;
    String pesoalnacer;
    String pesoaldestete;
    String prodpor;

    public Animal(int nro, Date fechaden, String sexo, String raza, String color, String madre, String padre, String pesoalnacer, String pesoaldestete, String prodpor) {
        this.nro = nro;
        this.fechaden = fechaden;
        this.sexo = sexo;
        this.raza = raza;
        this.color = color;
        this.madre = madre;
        this.padre = padre;
        this.pesoalnacer = pesoalnacer;
        this.pesoaldestete = pesoaldestete;
        this.prodpor = prodpor;
    }

    public Animal(int aInt) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public int getNro() {
        return nro;
    }

    public void setNro(int nro) {
        this.nro = nro;
    }

    public Date getFechaden() {
        return fechaden;
    }

    public void setFechaden(Date fechaden) {
        this.fechaden = fechaden;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getRaza() {
        return raza;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getMadre() {
        return madre;
    }

    public void setMadre(String madre) {
        this.madre = madre;
    }

    public String getPadre() {
        return padre;
    }

    public void setPadre(String padre) {
        this.padre = padre;
    }

    public String getPesoalnacer() {
        return pesoalnacer;
    }

    public void setPesoalnacer(String pesoalnacer) {
        this.pesoalnacer = pesoalnacer;
    }

    public String getPesoaldestete() {
        return pesoaldestete;
    }

    public void setPesoaldestete(String pesoaldestete) {
        this.pesoaldestete = pesoaldestete;
    }

    public String getProdpor() {
        return prodpor;
    }

    public void setProdpor(String prodpor) {
        this.prodpor = prodpor;
    }

    public String getId() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
