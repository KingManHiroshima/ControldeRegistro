/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TableView;

import Helpers.DbConnect;
import Models.Animal;
import java.awt.event.MouseEvent;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Tk
 */
public class TableViewController implements Initializable {

    @FXML
    private TableView<Animal> animalsTable;
    @FXML
    private TableColumn<Animal, String> nroCol;
    @FXML
    private TableColumn<Animal, String> fechaCol;
    @FXML
    private TableColumn<Animal, String> sexoCol;
    @FXML
    private TableColumn<Animal, String> razaCol;
    @FXML
    private TableColumn<Animal, String> colorCol;
    @FXML
    private TableColumn<Animal, String> madreCol;
    @FXML
    private TableColumn<Animal, String> padreCol;
    @FXML
    private TableColumn<Animal, String> pesonCol;
    @FXML
    private TableColumn<Animal, String> pesodCol;
    @FXML
    private TableColumn<Animal, String> prodCol;
    @FXML
    private TableColumn<Animal, String> editCol;

    String query = null;
    Connection connection = null;
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;
    Animal animal = null;

    ObservableList<Animal> AnimalList = FXCollections.observableArrayList();

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        loadDate();
    }

    @FXML
    private void close(MouseEvent event) {
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        stage.close();
    }

    @FXML
    private void getAddView(MouseEvent event) {
    }

    @FXML
    private void refreshTable() {
        try {
            AnimalList.clear();

            query = "SELECT * FROM `item`";
            preparedStatement = connection.prepareStatement(query);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                AnimalList.add(new Animal(
                        resultSet.getInt("nro.delanimal"),
                        resultSet.getDate("fechadenacimiento"),
                        resultSet.getString("sexo"),
                        resultSet.getString("raza"),
                        resultSet.getString("color"),
                        resultSet.getString("madre"),
                        resultSet.getString("padre"),
                        resultSet.getString("pesoalnacer"),
                        resultSet.getString("pesoaldestete"),
                        resultSet.getString("producidopor")));
                animalsTable.setItems(AnimalList);
            }

        } catch (SQLException ex) {
            Logger.getLogger(TableViewController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void print(MouseEvent event) {
    }

    private void loadDate() {

        connection = DbConnect.getConnect();
        refreshTable();

        nroCol.setCellValueFactory(new PropertyValueFactory<>("nro"));
        fechaCol.setCellValueFactory(new PropertyValueFactory<>("fechaden"));
        sexoCol.setCellValueFactory(new PropertyValueFactory<>("sexo"));
        razaCol.setCellValueFactory(new PropertyValueFactory<>("raza"));
        colorCol.setCellValueFactory(new PropertyValueFactory<>("color"));
        madreCol.setCellValueFactory(new PropertyValueFactory<>("madre"));
        padreCol.setCellValueFactory(new PropertyValueFactory<>("padre"));
        pesonCol.setCellValueFactory(new PropertyValueFactory<>("pesoalnacer"));
        pesodCol.setCellValueFactory(new PropertyValueFactory<>("pesoaldestete"));
        prodCol.setCellValueFactory(new PropertyValueFactory<>("prodpor"));

    }
}
